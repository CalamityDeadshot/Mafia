package com.app.mafia.helpers.eventTypes

enum class SubjectEvent {
    KILL, VOTE_KICK, FOUL,
}