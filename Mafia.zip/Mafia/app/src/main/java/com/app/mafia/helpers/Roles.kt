package com.app.mafia.helpers

enum class Roles {
    PEACEFUL, MAFIA, COMMISSIONER, DON, EMPTY
}