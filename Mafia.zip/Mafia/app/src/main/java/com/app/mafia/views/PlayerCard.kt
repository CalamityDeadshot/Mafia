package com.app.mafia.views

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.AttributeSet
import android.view.Gravity
import android.view.MenuItem
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.PopupMenu
import androidx.constraintlayout.widget.ConstraintLayout
import com.app.mafia.R
import com.app.mafia.helpers.Roles
import com.app.mafia.models.PlayerModel
import kotlinx.android.synthetic.main.player_card.view.*

class PlayerCard(context: Context) : ConstraintLayout(context), PlayerPopupMenu.OnMenuItemClickListener {

    lateinit var model: PlayerModel
    var popupMenu: PlayerPopupMenu
    init {
        popupMenu = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            PlayerPopupMenu(this.context, this, Gravity.NO_GRAVITY, R.attr.actionDropDownStyle, 0)
        } else {
            PlayerPopupMenu(this.context, this, Gravity.NO_GRAVITY)
        }
        popupMenu.setOnMenuItemClickListener(this)
        (context as Activity).menuInflater.inflate(R.menu.player_card_menu, popupMenu.menu)
    }

    var showRole = false
        @SuppressLint("UseCompatLoadingForDrawables")
        set(value) {
            val oldValue = field
            field = value
            if (value == oldValue) return
            this.animate().withLayer()
                .rotationY(90f)
                .setDuration(300)
                .setInterpolator(AccelerateInterpolator())
                .withEndAction {
                    run {
                        if (value) {
                            base.background = context.getDrawable(
                                when (model.role) {
                                    Roles.PEACEFUL -> R.drawable.card_peaceful
                                    Roles.COMMISSIONER -> R.drawable.card_commissioner
                                    Roles.DON -> R.drawable.card_don
                                    Roles.MAFIA -> R.drawable.card_mafia
                                    Roles.EMPTY -> R.drawable.player_card_placeholder
                                }
                            )
                            text.text = when (model.role) {
                                Roles.PEACEFUL -> "P"
                                Roles.COMMISSIONER -> "C"
                                Roles.DON -> "D"
                                Roles.MAFIA -> "M"
                                Roles.EMPTY -> model.number.toString()
                            }
                            text.setTextColor(
                                resources.getColor(
                                    when (model.role) {
                                        Roles.EMPTY -> R.color.black_overlay
                                        Roles.PEACEFUL -> R.color.black_overlay
                                        else -> android.R.color.white
                                    }
                                )
                            )
                            showRoleButton.setImageResource(android.R.drawable.ic_menu_revert)
                        } else {
                            base.background = context.getDrawable(R.drawable.player_card_background)
                            text.text = model.number.toString()
                            text.setTextColor(resources.getColor(R.color.black_overlay))
                            showRoleButton.setImageResource(android.R.drawable.ic_menu_view)
                            text.text = model.number.toString()
                        }

                        // second quarter turn
                        this.rotationY = -90f
                        this.animate().withLayer()
                            .rotationY(0f)
                            .setDuration(300)
                            .setInterpolator(DecelerateInterpolator())
                            .start()
                    }
                }.start()
        }

    constructor(context: Context, attrs : AttributeSet) : this(context) {
        initView()
    }

    fun initView() {
        View.inflate(context, R.layout.player_card, this)
    }

    override fun onMenuItemClick(item: MenuItem, position: Int): Boolean {
        return false
    }


}