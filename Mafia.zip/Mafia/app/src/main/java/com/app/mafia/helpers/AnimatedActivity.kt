package com.app.mafia.helpers

import android.animation.Animator
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.app.Activity
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.app.mafia.R

open class AnimatedActivity : AppCompatActivity(), Animator.AnimatorListener {

    lateinit var expand : ObjectAnimator
    lateinit var shrink : ObjectAnimator
    lateinit var fadeIn : ObjectAnimator
    lateinit var fadeOut : ObjectAnimator

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleAnimation()
    }

    private fun handleAnimation() {
        expand = ObjectAnimator.ofPropertyValuesHolder(
            this.findViewById<View>(R.id.bubble),
            PropertyValuesHolder.ofFloat("scaleX", Global.scaleFactor),
            PropertyValuesHolder.ofFloat("scaleY", Global.scaleFactor)
        ).apply {
            duration = Global.shrinkExpandDuration
            interpolator = AccelerateInterpolator()
        }
        expand.addListener(this)
        expand.start()

        shrink = ObjectAnimator.ofPropertyValuesHolder(
            this.findViewById<View>(R.id.bubble),
            PropertyValuesHolder.ofFloat("scaleX", 0f),
            PropertyValuesHolder.ofFloat("scaleY", 0f)
        ).apply {
            duration = Global.shrinkExpandDuration
            interpolator = AccelerateInterpolator()
        }
        shrink.addListener(this)

        fadeIn = ObjectAnimator.ofPropertyValuesHolder(
            this.findViewById<View>(R.id.opacityContainer),
            PropertyValuesHolder.ofFloat("alpha", 1f)
        ).apply {
            duration = 300
            interpolator = AccelerateInterpolator()
        }
        fadeIn.start()
        fadeIn.addListener(this)

        fadeOut = ObjectAnimator.ofPropertyValuesHolder(
            this.findViewById<View>(R.id.opacityContainer),
            PropertyValuesHolder.ofFloat("alpha", 0f)
        ).apply {
            duration = 300
            interpolator = AccelerateInterpolator()
        }
        fadeOut.addListener(this)
    }

    var lastPressedTime: Long = 0
    var PERIOD = 2000
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {

        if (event!!.keyCode == KeyEvent.KEYCODE_BACK) {
            when (event.action) {
                KeyEvent.ACTION_DOWN -> {
                    if (event.downTime - lastPressedTime < PERIOD) {
                        closeActivity()
                    } else {
                        Toast.makeText(this, "Press again to close the game", Toast.LENGTH_LONG).show()
                        lastPressedTime = event.eventTime
                    }
                }
            }
        }
        return false
    }

    fun closeActivity() {
        fadeOut.start()
    }

    override fun onAnimationRepeat(p0: Animator?) {
    }

    override fun onAnimationEnd(p0: Animator?) {
        when (p0) {
            expand -> {
                this.findViewById<View>(R.id.base).background = null
                this.findViewById<View>(R.id.bubble).visibility = View.GONE
                this.findViewById<View>(R.id.opacityContainer).visibility = View.VISIBLE
                fadeIn.start()
            }
            shrink -> {
                finish()
                overridePendingTransition(0,0)
            }
            fadeOut -> {
                this.findViewById<View>(R.id.bubble).visibility = View.VISIBLE
                this.findViewById<View>(R.id.base).setBackgroundColor(resources.getColor(R.color.colorPrimaryLight))
                shrink.start()
            }
        }
    }

    override fun onAnimationCancel(p0: Animator?) {
    }

    override fun onAnimationStart(p0: Animator?) {
    }
}