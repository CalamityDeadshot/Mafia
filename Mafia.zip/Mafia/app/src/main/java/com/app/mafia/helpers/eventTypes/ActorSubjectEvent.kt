package com.app.mafia.helpers.eventTypes

enum class ActorSubjectEvent {
    VOTE_SUBMIT
}