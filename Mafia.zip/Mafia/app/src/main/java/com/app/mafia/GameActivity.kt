package com.app.mafia

import android.animation.Animator
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import androidx.recyclerview.widget.GridLayoutManager
import com.app.mafia.adapters.PlayersAdapter
import com.app.mafia.helpers.*
import com.app.mafia.helpers.eventTypes.SubjectEvent
import com.app.mafia.models.PlayerModel
import com.app.mafia.views.PlayerPopupMenu
import kotlinx.android.synthetic.main.activity_distribution.playersRecycler
import kotlinx.android.synthetic.main.activity_game.*

class GameActivity : AnimatedActivity(), Animator.AnimatorListener, AdapterView.OnItemClickListener, PlayerPopupMenu.OnMenuItemClickListener {

    lateinit var game: Game
    lateinit var adapter: PlayersAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        setContentView(R.layout.activity_game)
        super.onCreate(savedInstanceState)
        setSupportActionBar(gameToolbar)
        supportActionBar!!.title = "Game"
        playersRecycler.layoutManager = GridLayoutManager(this, Global.calculateNoOfColumns(this, 120f))
        val players = ArrayList<PlayerModel>()
        val roles: ArrayList<Roles> = (intent.extras!!.getSerializable("playerRoles") as ArrayList<Roles>)
        for (i in 0 until roles.size) {
            players.add(PlayerModel(roles[i], i + 1))
        }
        adapter = PlayersAdapter(this, players, this, this)
        playersRecycler.adapter = adapter
        game = Game(this, roles)
    }

    override fun onAnimationEnd(p0: Animator?) {
        when (p0) {

        }
        super<AnimatedActivity>.onAnimationEnd(p0)
    }

    override fun onItemClick(p0: AdapterView<*>?, view: View?, pos: Int, id: Long) {

    }

    override fun onMenuItemClick(item: MenuItem, position: Int): Boolean {
        when (item.itemId) {
            R.id.gotKilled -> game.addEvent(GameEvent(SubjectEvent.KILL, position))
            R.id.regFoul -> game.addEvent((GameEvent(SubjectEvent.FOUL, position)))
        }

        return false
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        MenuInflater(application).inflate(R.menu.game_toolbar_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }
}