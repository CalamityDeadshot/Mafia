package com.app.mafia.helpers

import com.app.mafia.helpers.eventTypes.ActorSubjectEvent
import com.app.mafia.helpers.eventTypes.Event
import com.app.mafia.helpers.eventTypes.SubjectEvent

class GameEvent {
    var eString: String

    constructor(e: Event) {
        eString = when (e) {
            Event.DAY -> "Day has come"
            Event.NIGHT -> "Night has come"
        }
    }

    constructor(e: SubjectEvent, subject: Int) {
        eString = when (e) {
            SubjectEvent.FOUL -> "Player $subject receives a foul"
            SubjectEvent.KILL -> "Player $subject gets killed this night"
            SubjectEvent.VOTE_KICK -> "Player $subject is imprisoned by vote"
        }
    }
    constructor(e: ActorSubjectEvent, actor: Int, subject: Int) {
        eString = when (e) {
            ActorSubjectEvent.VOTE_SUBMIT -> "Player $actor submits player $subject for a vote"
        }
    }


}