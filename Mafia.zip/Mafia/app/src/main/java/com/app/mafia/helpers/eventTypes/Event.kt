package com.app.mafia.helpers.eventTypes

enum class Event {
    DAY, NIGHT
}